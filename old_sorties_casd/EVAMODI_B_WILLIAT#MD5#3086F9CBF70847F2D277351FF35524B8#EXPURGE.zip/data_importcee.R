library(data.table)
library(glue)
col_gestes <- c("pyiddos","dtemissiondevis",  "dtfacture", "siretsct","mtwpsolde", "familyname","subtypename", "wpsurface")



mpr_2021gestes <- lapply(c("1","2","3","4"),
                         function(x){fread(file = glue("Ma Prime Rénov_MPR Instruction Nationale_2021/2021T{x}/InstructionNat_engt_2021T{x}_Geste_CASD.csv"))%>%
                             .[,..col_gestes] #c("pyiddos","siretsct","mtwpsolde")
                         }
) %>% 
  rbindlist()
gestesnames <- mpr_2021gestes[familyname %in% c("Isolation", "Chauffage et chauffe-eau")]

## Pad the gestes list with the few that aren't in the 2021 gestes list
gestes_iso <- c(unique(gestesnames[familyname == "Isolation"]$subtypename), "Toitures et combles")
gestes_th <- unique(gestesnames[familyname == "Chauffage et chauffe-eau"]$subtypename)
mpr_2021cee <- lapply(c("1","2","3","4"),
                      function(x){fread(file = glue("Ma Prime Rénov_MPR Instruction Nationale_2021/2021T{x}/InstructionNat_engt_2021T{x}_CEE_CASD.csv"))%>%
                          .[,c("pyiddos","subtypenamecee","mtceeinit","mtcee","mtceesoldeinit", "mtceesolde")] #c("pyiddos","siretsct","mtwpsolde")
                      }
) %>% 
  rbindlist() %>% 
  .[mtceesolde >0] %>% 
  .[, familyname := case_when(subtypenamecee %in%gestes_iso  ~ "Isolation",
                              subtypenamecee %in% gestes_th ~ "Chauffage et chauffe-eau",
                              TRUE~subtypenamecee)] %>%
  rename(subtypename = subtypenamecee) %>% 
  .[familyname %in% c("Isolation", "Chauffage et chauffe-eau")]

# n = 9567 gestes non attribués aux 2 classes.

gestes_nonID <- unique(mpr_2021cee[!familyname %in% c("Isolation", "Chauffage et chauffe-eau")]$subtypename)

mpr_2021ceetravaux <- mpr_2021cee[, .N, by = .(pyiddos,familyname)]

#duplicatedID <- mpr_2021ceet ravaux[duplicated(mpr_2021ceetravaux$pyiddos)]

duplicatedID <- mpr_2021ceetravaux[pyiddos %in% mpr_2021ceetravaux[duplicated(mpr_2021ceetravaux, by = "pyiddos")]$pyiddos]
#unique(duplicatedID$pyiddos)
#unique(mpr_2021ceetravaux$pyiddos)
col_select_up <- c("PYIDDOS", "CODEINSEE","RFRSUM", "DTOCTROI", "DTDECAVANCE","DTPAIEMENTAVANCE", "DTPAIEMENTSOLDE","TTMTWP", "MTWPAVANCE","TTMTWPSOLDE", "TTMTCEESOLDE")

col_select <- stringr::str_to_lower(col_select_up)
mpr_2021 <- lapply(c("1","2","3","4"),
                   function(x){
                     fread(file = glue("Ma Prime Rénov_MPR Instruction Nationale_2021/2021T{x}/InstructionNat_engt_2021T{x}_Dossier_CASD.csv")) %>% 
                       .[,..col_select]
                     
                   }) %>% 
  rbindlist()

mpr_2021ceetravaux[pyiddos %in% duplicated(mpr_2021ceetravaux$pyiddos)]
check <- mpr_2021ceetravaux[pyiddos %in% ((mpr_2021ceetravaux[N>1, .N, by = .(pyiddos)]$pyiddos))]

mpr_2021cee_matched <- mpr_2021ceetravaux %>% 
  left_join(mpr_2021[, .(pyiddos,codeinsee,rfrsum)], by = "pyiddos")

# filter <- mpr_2021cee_matched[mpr_2021cee_matched[pyiddos%in%duplicatedID$pyiddos]]
# check <- mpr_2021cee_matched[filter]
# 
# test <- mpr_2021cee_matched[pyiddos %in% duplicatedID$pyiddos] %>% 
#   .[,checksum := sum(rfrsum)/mean(rfrsum), by = .(pyiddos)]
# 
# failedchecksum <- test[!checksum==2]

saveRDS(mpr_2021cee_matched, file = "mpr_2021cee_matched.rds")
write(gestes_nonID, file = "gestes_nonID.txt")
